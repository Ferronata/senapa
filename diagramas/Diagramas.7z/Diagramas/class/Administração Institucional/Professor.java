package Administra��o Institucional;

public class Professor extends PessoaEscola {
 
	private Disciplina disciplina;
	 
	private Disciplina disciplina;
	 
}
 
