package Administra��o Institucional;

public class Empresa extends PessoaJuridica {
 
}
 
