package Administra��o Institucional;

public class PessoaEscola extends PessoaFisica {
 
	private String matricula;
	 
}
 
