package Administra��o Institucional;

public class PessoaJuridica extends Pessoa {
 
	private String cnpj;
	 
	private String inscricaoEstadual;
	 
	private String inscricaoMunicipal;
	 
}
 
