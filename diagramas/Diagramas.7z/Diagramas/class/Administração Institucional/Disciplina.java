package Administra��o Institucional;

public class Disciplina {
 
	private Integer codigo;
	 
	private String nome;
	 
	private Professor professor;
	 
	private Professor professor;
	 
}
 
