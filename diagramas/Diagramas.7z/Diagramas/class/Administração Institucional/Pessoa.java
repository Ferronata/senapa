package Administra��o Institucional;

public class Pessoa {
 
	private String nome;
	 
	private String email;
	 
	private String site;
	 
}
 
