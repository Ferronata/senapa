package Administra��o Institucional;

public class Aluno extends PessoaEscola {
 
}
 
