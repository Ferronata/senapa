package Administra��o Institucional;

public class PessoaFisica extends Pessoa {
 
	private String cpf;
	 
	private String dataNascimento;
	 
}
 
